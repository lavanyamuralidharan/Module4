$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/lmuralid/Desktop/Module4 practical/Module4Practical/src/test/resources/EducationalDetails/Eductional.feature");
formatter.feature({
  "line": 1,
  "name": "EducationalDetails",
  "description": "",
  "id": "educationaldetails",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2953162400,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Invalid Title",
  "description": "",
  "id": "educationaldetails;invalid-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the heading of the page is not found",
  "keyword": "When "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 398116400,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.the_heading_of_the_page_is_not_found()"
});
formatter.result({
  "duration": 29959400,
  "status": "passed"
});
formatter.before({
  "duration": 1981153100,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Empty Graduation",
  "description": "",
  "id": "educationaldetails;empty-graduation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "user enters empty Graduation",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "displays select Graduation",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 117805900,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_empty_Graduation()"
});
formatter.result({
  "duration": 240338600,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_select_Graduation()"
});
formatter.result({
  "duration": 2714770900,
  "status": "passed"
});
formatter.before({
  "duration": 2276594600,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Empty Percentage",
  "description": "",
  "id": "educationaldetails;empty-percentage",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "user enters empty percentage",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "displays enter percentage",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 152920000,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_empty_percentage()"
});
formatter.result({
  "duration": 297684300,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_enter_percentage()"
});
formatter.result({
  "duration": 2385152000,
  "status": "passed"
});
formatter.before({
  "duration": 2960388300,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Empty PassingYear",
  "description": "",
  "id": "educationaldetails;empty-passingyear",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "user enters empty passingYear",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "displays enter passingYear",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 123330900,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_empty_passingYear()"
});
formatter.result({
  "duration": 265238300,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_enter_passingYear()"
});
formatter.result({
  "duration": 496206400,
  "status": "passed"
});
formatter.before({
  "duration": 1620646400,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Empty ProjectName",
  "description": "",
  "id": "educationaldetails;empty-projectname",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "user enters empty projectName",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "displays enter projectName",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 2173826900,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_empty_projectName()"
});
formatter.result({
  "duration": 373389200,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_enter_projectName()"
});
formatter.result({
  "duration": 2103773600,
  "status": "passed"
});
formatter.before({
  "duration": 1695562400,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "Verify the Techonologies used",
  "description": "",
  "id": "educationaldetails;verify-the-techonologies-used",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user enters Techonologies used",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "displays \u0027Please select Techonologies Used\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 3504194500,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_Techonologies_used()"
});
formatter.result({
  "duration": 363426600,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_Please_select_Techonologies_Used()"
});
formatter.result({
  "duration": 2116580700,
  "status": "passed"
});
formatter.before({
  "duration": 1553724500,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Verify the other Techonologies used",
  "description": "",
  "id": "educationaldetails;verify-the-other-techonologies-used",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "user enters other Techonologies used",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "displays \u0027Please fill other Techonologies Used\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 166104400,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_other_Techonologies_used()"
});
formatter.result({
  "duration": 507921200,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_Please_fill_other_Techonologies_Used()"
});
formatter.result({
  "duration": 550819400,
  "status": "passed"
});
formatter.before({
  "duration": 1504853500,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Make Payment",
  "description": "",
  "id": "educationaldetails;make-payment",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user is on \u0027EducationalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "user enters Valid Details",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "displays SucessMessage",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_is_on_EducationalDetails_page()"
});
formatter.result({
  "duration": 1821018500,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.user_enters_Valid_Details()"
});
formatter.result({
  "duration": 469848700,
  "status": "passed"
});
formatter.match({
  "location": "EducationDetails_StepDefination.displays_SucessMessage()"
});
formatter.result({
  "duration": 10818500,
  "status": "passed"
});
});