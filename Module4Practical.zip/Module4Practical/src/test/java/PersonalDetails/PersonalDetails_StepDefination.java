package PersonalDetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactoryBean.PersonalDeatilsPageFactory;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class PersonalDetails_StepDefination {
	private WebDriver driver;
	private PersonalDeatilsPageFactory detailsPageFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\lmuralid\\Desktop\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	@Given("^user is on 'PersonalDetails' page$")
	public void user_is_on_PersonalDetails_page() throws Throwable {
		driver.get("C:\\Users\\lmuralid\\Desktop\\WebPages Set B\\PersonalDetails.html");
		detailsPageFactory	= new PersonalDeatilsPageFactory(driver);
	   
	}
	@When("^the heading of the page is not found$")
	public void the_heading_of_the_page_is_not_found() throws Throwable {
		//Thread.sleep(2000);
	 String heading=driver.getTitle();
	 Assert.assertEquals("Personal Details", heading);
	 if(heading.equals("Personal Details"))
	 {
		 System.out.println("Heading matches");
	 }
	 else {
		 System.out.println("Text is not found on page");
	 }
	}

	
	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		detailsPageFactory.setFirstName("");
		detailsPageFactory.setNext();
	}

	@Then("^displays 'Please fill the first Name'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
		//Thread.sleep(2000);
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters invalid Last name$")
	public void user_enters_invalid_Last_name() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("");
		
		detailsPageFactory.setNext(); 
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
		//Thread.sleep(2000);
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters invalid Email$")
	public void user_enters_invalid_Email() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh");
		detailsPageFactory.setNext(); 
	    
	}

	@Then("^displays 'Please fill Email'$")
	public void displays_Please_fill_Email() throws Throwable {
		//Thread.sleep(2000);
		String expectedMessage="Please enter valid Email Id.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	   
	} 
	@When("^user enters empty contact num$")
	public void user_enters_empty_contact_num() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh@gmail.com");
		detailsPageFactory.setContactnum("");
		detailsPageFactory.setNext(); 
	}

	@Then("^displays 'Please fill Contact num'$")
	public void displays_Please_fill_Contact_num() throws Throwable {
	//	Thread.sleep(2000);
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}
	
	@When("^user enters invalis contact num$")
	public void user_enters_invalis_contact_num() throws Throwable {
		
			detailsPageFactory.setFirstName("lava");
			detailsPageFactory.setLastname("kkkkk");
			detailsPageFactory.setEmail("hhh@gmail.com");
			detailsPageFactory.setContactnum("34567");
			detailsPageFactory.setNext(); 
	}

	@Then("^displays please enter valid contact no$")
	public void displays_please_enter_valid_contact_no() throws Throwable {
		
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters empty addressaline(\\d+)$")
	public void user_enters_empty_addressaline(int arg1) throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh@gmail.com");
		detailsPageFactory.setContactnum("9487585684");
		detailsPageFactory.setAddress1("");
		detailsPageFactory.setNext();
	}

	@Then("^displays please enter AddressLine(\\d+)$")
	public void displays_please_enter_AddressLine(int arg1) throws Throwable {
		
		String expectedMessage="Please fill the address line 1";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters empty addressaline$")
	public void user_enters_empty_addressaline() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh@gmail.com");
		detailsPageFactory.setContactnum("9487585684");
		detailsPageFactory.setAddress1("housee");
		detailsPageFactory.setAddress2("");
		detailsPageFactory.setNext();
	}

	@Then("^displays please enter AddressLine$")
	public void displays_please_enter_AddressLine() throws Throwable {
		
		String expectedMessage="Please fill the address line 2";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters empty city$")
	public void user_enters_empty_city() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh@gmail.com");
		detailsPageFactory.setContactnum("9487585684");
		detailsPageFactory.setAddress1("housee");
		detailsPageFactory.setAddress2("hhhhh");
		detailsPageFactory.setCity("");
		detailsPageFactory.setNext();
	}

	@Then("^displays select city$")
	public void displays_select_city() throws Throwable {
		
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters empty state$")
	public void user_enters_empty_state() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh@gmail.com");
		detailsPageFactory.setContactnum("9487585684");
		detailsPageFactory.setAddress1("housee");
		detailsPageFactory.setAddress2("hhhhh");
		detailsPageFactory.setCity("Chennai");
		detailsPageFactory.setState("");
		detailsPageFactory.setNext();
	}

	@Then("^displays select state$")
	public void displays_select_state() throws Throwable {
	//	Thread.sleep(2000);
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user clicks Next$")
	public void user_clicks_Next() throws Throwable {
		detailsPageFactory.setFirstName("lava");
		detailsPageFactory.setLastname("kkkkk");
		detailsPageFactory.setEmail("hhh@gmail.com");
		detailsPageFactory.setContactnum("9487585684");
		detailsPageFactory.setAddress1("housee");
		detailsPageFactory.setAddress2("hhhhh");
		detailsPageFactory.setCity("Chennai");
		detailsPageFactory.setState("Tamilnadu");
		detailsPageFactory.setNext();
		
	    
	}

	@Then("^displays SuccessMessage$")
	public void displays_SuccessMessage() throws Throwable {
		driver.switchTo().alert().accept();
		driver.get("C:\\Users\\lmuralid\\Desktop\\WebPages Set B\\EducationalDetails.html");
		driver.close();
	}

}

