package EducationalDetails;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactoryBean.EducationaldetailsPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationDetails_StepDefination {
	private WebDriver driver;
	private EducationaldetailsPageFactory edetails;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\lmuralid\\Desktop\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	@Given("^user is on 'EducationalDetails' page$")
	public void user_is_on_EducationalDetails_page() throws Throwable {
		driver.get("C:\\Users\\lmuralid\\Desktop\\WebPages Set B\\EducationalDetails.html");
		edetails	= new EducationaldetailsPageFactory(driver);
	}

	@When("^the heading of the page is not found$")
	public void the_heading_of_the_page_is_not_found() throws Throwable {
		String heading=driver.getTitle();
		 Assert.assertEquals("Educational Details", heading);
		 if(heading.equals("Educational Details"))
		 {
			 System.out.println("Heading matches");
		 }
		 else {
			 System.out.println("Text is not found on page");
		 }
	}
		 @When("^user enters empty Graduation$")
		 public void user_enters_empty_Graduation() throws Throwable {
			edetails.setGraduation("");
			edetails.setRegister();
		 }

		 @Then("^displays select Graduation$")
		 public void displays_select_Graduation() throws Throwable {
			 Thread.sleep(2000);
				String expectedMessage="Please Select Graduation";
				String actualMessage=driver.switchTo().alert().getText();
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
				driver.close();
		 }
		 @When("^user enters empty percentage$")
		 public void user_enters_empty_percentage() throws Throwable {
			 edetails.setGraduation("BE");
			 edetails.setPercentage("");
				edetails.setRegister();
		 }

		 @Then("^displays enter percentage$")
		 public void displays_enter_percentage() throws Throwable {
			 Thread.sleep(2000);
				String expectedMessage="Please fill Percentage detail";
				String actualMessage=driver.switchTo().alert().getText();
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
				driver.close();
		 }
		 @When("^user enters empty passingYear$")
		 public void user_enters_empty_passingYear() throws Throwable {
			 edetails.setGraduation("BE");
			 edetails.setPercentage("67");
			 edetails.setPassingYear("");
				edetails.setRegister();
		 }

		 @Then("^displays enter passingYear$")
		 public void displays_enter_passingYear() throws Throwable {
			 String expectedMessage="Please fill Passing Year";
				String actualMessage=driver.switchTo().alert().getText();
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
				driver.close();
		 }
		 
		 @When("^user enters empty projectName$")
		 public void user_enters_empty_projectName() throws Throwable {
			 edetails.setGraduation("BE");
			 edetails.setPercentage("67");
			 edetails.setPassingYear("2019");
			 edetails.setProjectname("");
				edetails.setRegister();
		 }

		 @Then("^displays enter projectName$")
		 public void displays_enter_projectName() throws Throwable {
			 String expectedMessage="Please fill Project Name";
				String actualMessage=driver.switchTo().alert().getText();
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
				driver.close();
		 }
		 
		 @When("^user enters Techonologies used$")
			public void user_enters_Techonologies_used() throws Throwable {
			 edetails.setGraduation("BTech");
			 edetails.setPercentage("80%");
			 edetails.setPassingYear("2016");
			 edetails.setProjectname("Java");

			 edetails.setRegister();
			}

			@Then("^displays 'Please select Techonologies Used'$")
			public void displays_Please_select_Techonologies_Used() throws Throwable {
				String expectedMessage = "Please Select Technologies Used";
				String actualMessage = driver.switchTo().alert().getText();
				// Thread.sleep(5000);
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
				driver.close();
			}

			@When("^user enters other Techonologies used$")
			public void user_enters_other_Techonologies_used() throws Throwable {
				edetails.setGraduation("BTech");
				edetails.setPercentage("80%");
				edetails.setPassingYear("2016");
				edetails.setProjectname("Java");
				edetails.setTechonologies();
				edetails.setOtherTechonologies("");
				edetails.setRegister();
			}

			@Then("^displays 'Please fill other Techonologies Used'$")
			public void displays_Please_fill_other_Techonologies_Used() throws Throwable {
				String expectedMessage = "Please fill other Technologies Used";
				String actualMessage = driver.switchTo().alert().getText();
				
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
				driver.close();
			}
		 @When("^user enters Valid Details$")
		 public void user_enters_Valid_Details() throws Throwable {
			 edetails.setGraduation("BTech");
			 edetails.setPercentage("80%");
			 edetails.setPassingYear("2016");
			 edetails.setProjectname("Java");
			 edetails.setTechonologies1();
			 edetails.setRegister();
		 }

		 @Then("^displays SucessMessage$")
		 public void displays_SucessMessage() throws Throwable {
			 String expectedMessage = "Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
				String actualMessage = driver.switchTo().alert().getText();
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.switchTo().alert().accept();
	}

}

