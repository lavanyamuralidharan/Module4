package EducationalDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	
	features= {"C:\\Users\\lmuralid\\Desktop\\Module4 practical\\Module4Practical\\src\\test\\resources\\EducationalDetails\\Eductional.feature"},
glue= {"EducationalDetails"},
strict = true,	
dryRun=false,
monochrome=false,
format = {"pretty" , "html:test-output"}
)
public class EducationDetails_TestRunner {

}
