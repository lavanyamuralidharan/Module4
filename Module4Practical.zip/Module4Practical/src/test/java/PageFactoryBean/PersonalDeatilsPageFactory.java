package PageFactoryBean;

import org.hamcrest.Factory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class PersonalDeatilsPageFactory {
	WebDriver driver;
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(linkText="Next")
	@CacheLookup
	WebElement next;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement Email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement contactnum;
	
	
	@FindBy(name="address1")
	@CacheLookup
	WebElement address1;
	
	@FindBy(name="address2")
	@CacheLookup
	WebElement address2;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	public WebElement getState() {
		return state;
	}
	public void setState(String state) {
		this.state.sendKeys(state);
	}
	public WebElement getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city.sendKeys(city);;
	}
	public WebElement getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}
	public WebElement getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}
	public WebElement getContactnum() {
		return contactnum;
	}
	public void setContactnum(String contactnum) {
		this.contactnum.sendKeys(contactnum);
	}
	public WebElement getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		this.Email.sendKeys(email);;
	}
	public WebElement getNext() {
		return next;
	}
	public void setNext() {
		this.next.click();
	}
	public WebElement getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}
	public WebElement getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public PersonalDeatilsPageFactory(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}

}
